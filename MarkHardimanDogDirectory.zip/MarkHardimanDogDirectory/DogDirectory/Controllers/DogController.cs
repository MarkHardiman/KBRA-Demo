﻿using MarkHardimanDogDirectory.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace MarkHardimanDogDirectory.Controllers
{
    public class DogController : Controller
    {
        public const string DOG_BREED_LIST = "api/breeds/list";
        public const string RANDOM_IMAGE_PART_1 = "api/breed/";
        public const string RANDOM_IMAGE_PART_2 = "/images/random";

        public ActionResult Index()
        {
            DogBreed dogBreeds = null;

            try
            {
                using (var client = new HttpClient())
                {
                    // Get base URL from web.config (production would be encrypted)

                    client.BaseAddress = new Uri(ConfigurationManager.AppSettings["DogBreedAPI"]);
                    client.DefaultRequestHeaders.Clear();

                    // Get the Dog Breed List be specifying the rsource of interest

                    var responseTask = client.GetAsync(DOG_BREED_LIST);
                    responseTask.Wait();
                    var result = responseTask.Result;

                    // Use the HTTP Status code from the response instead of looking into the string returned from the API

                    if (result.IsSuccessStatusCode)
                    {
                        var response = result.Content.ReadAsStringAsync().Result;
                        dogBreeds = JsonConvert.DeserializeObject<DogBreed>(response);
                    }
                    else
                    {
                        ModelState.AddModelError("", "Unable to get Dog Breed List");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return View(dogBreeds);
        }

        public ActionResult ShowRandomImage(string szBreedName)
        {
            DogImage dogImage = null;

            try
            {
                using (var client = new HttpClient())
                {
                    // Get base URL from web.config (production would be encrypted)

                    client.BaseAddress = new Uri(ConfigurationManager.AppSettings["DogBreedAPI"]);
                    client.DefaultRequestHeaders.Clear();

                    // Get the Dog Breed List be specifying the rsource of interest

                    StringBuilder sbResource = new StringBuilder();
                    sbResource.Append(RANDOM_IMAGE_PART_1);
                    sbResource.Append(szBreedName);
                    sbResource.Append(RANDOM_IMAGE_PART_2);

                    var responseTask = client.GetAsync(sbResource.ToString());
                    responseTask.Wait();
                    var result = responseTask.Result;

                    // Use the HTTP Status code from the response instead of looking into the string returned from the API

                    if (result.IsSuccessStatusCode)
                    {
                        var response = result.Content.ReadAsStringAsync().Result;
                        dogImage = JsonConvert.DeserializeObject<DogImage>(response);
                        dogImage.BreedName = szBreedName;
                    }
                    else
                    {
                        ModelState.AddModelError("", "Unable to get random Dog Image");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
            return View(dogImage);
        }

    }
}