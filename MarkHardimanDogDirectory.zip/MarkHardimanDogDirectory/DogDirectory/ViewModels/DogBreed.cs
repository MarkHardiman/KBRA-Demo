﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services.Description;

namespace MarkHardimanDogDirectory.ViewModels
{
    public class DogBreed
    {
        [JsonProperty(PropertyName = "Status")]
        public string Status { get; set; }
        [JsonProperty(PropertyName = "Message")]
        public List<string> Message { get; set; }
    }
}