﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MarkHardimanDogDirectory.ViewModels
{
    public class DogImage
    {
        [JsonProperty(PropertyName = "Status")]
        public string Status { get; set; }
        [JsonProperty(PropertyName = "Message")]
        public string ImageURL { get; set; }
        public string BreedName { get; set; }
    }
}